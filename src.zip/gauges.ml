type t

type effect

let get_level l_type gauges = failwith "Unimplemented"

let consume_item item = failwith "Unimplemented"
