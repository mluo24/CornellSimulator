let hours_worked = [-1;-1;-1]
